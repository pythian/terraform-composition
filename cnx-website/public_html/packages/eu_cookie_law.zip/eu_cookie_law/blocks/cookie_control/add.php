<?php

/**
 * @project:   Urheberrechts Zentrale
 *
 * @author     Fabian Bitter
 * @copyright  (C) 2016 Fabian Bitter (www.bitter.de)
 * @version    1.1.2
 */

defined('C5_EXECUTE') or die('Access Denied.');

$this->inc("form.php");
