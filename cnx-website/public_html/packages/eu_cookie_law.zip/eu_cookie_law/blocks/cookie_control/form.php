<?php

/**
 * @project:   Urheberrechts Zentrale
 *
 * @author     Fabian Bitter
 * @copyright  (C) 2016 Fabian Bitter (www.bitter.de)
 * @version    1.1.2
 */

defined('C5_EXECUTE') or die('Access Denied.');

?>

<div class="alert alert-info">
    <?php echo t("This block type has not options."); ?>
</div>