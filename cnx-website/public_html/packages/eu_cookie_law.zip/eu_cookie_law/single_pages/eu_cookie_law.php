<?php

/**
* Project: EU Cookie Law Add-On
*
* @copyright 2017 Fabian Bitter
* @author Fabian Bitter (fabian@bitter.de)
* @version 1.1.2
*/

defined('C5_EXECUTE') or die('Access denied');
