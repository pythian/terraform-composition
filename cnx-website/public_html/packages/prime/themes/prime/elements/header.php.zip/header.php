<?php defined('C5_EXECUTE') or die("Access Denied.");
$this->inc('elements/header_top.php');?>

<header>
  <div class="row no-gutters g-0">
    <div class="top-bar col-12">
        <?php $a = new GlobalArea('Top Nav'); $a->display(); ?>
      <?php $a = new GlobalArea(' Account Button'); $a->display(); ?>
    </div>
    <div class="col-md-3 col-12 col-logo">
      <?php $a = new GlobalArea('Logo'); $a->display(); ?>

    </div>
    <div class="col-md-9 col-12 nav-right">
      <div class="nav-outer">
      <?php $a = new GlobalArea('Main Nav'); $a->display(); ?>
      </div>
      <div class="search-box">  <?php $a = new GlobalArea('Search'); $a->display(); ?></div>
      <a class="menu-icon d-xl-none d-block" href="javascript:void(0);">
        <span></span>
        <span></span>
        <span></span>
      </a>
    </div>
  </div>
</header>
<div class="mobile-menu">
  <a class="close-icon" href="javascript:void(0);">
    <span></span>
    <span></span>
    <span></span>
  </a>
  <div class="mobile-menu-inner">
    <div class="mobile-menu-top">
      <?php $stack = Stack::getByName('Mobile Menu Top'); $stack->display(); ?>
    </div>
    <div class="mobile-menu-btm">
      <?php $stack = Stack::getByName('Mobile Menu'); $stack->display(); ?>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
  $(window).scroll(function() {
    if ($(window).scrollTop() >= 200) {
        $("header").addClass("header_fixed");
    }else{
        $("header").removeClass("header_fixed");
    }
  });
  $('.menu-icon').click(function(){
    $('body').addClass('nav-open');
$('.menu-icon').addClass('active');
$('.mobile-menu').addClass('open');
});
$('.close-icon').click(function(){
  $('body').removeClass('nav-open');
$('.menu-icon').removeClass('active');
$('.mobile-menu').removeClass('open');
});
      if ($('#cyear').length) { $("#cyear").html(new Date().getFullYear()); }
         $('.arrow_up').click(function(){
           $("html, body").animate({
             scrollTop: 0
             }, 600);
         })



});

</script>
