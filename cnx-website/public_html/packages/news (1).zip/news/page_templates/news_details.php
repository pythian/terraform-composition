<?php defined('C5_EXECUTE') or die(_("Access Denied."));
$view->inc('elements/header.php');
$page = Page::getCurrentPage();
$ih = Loader::helper("image"); ?>


<section class="news-details">
    <?php

    $thumbnail = $page->getAttribute('news_thumbnail');
    $title = $page->getCollectionName();
    $description = $page->getAttribute('news_description');
    $category = $page->getAttribute('news_category');
    ?>

    <h2><?= $title; ?></h2>
    <span><?= $category; ?></span>
    <?php if (is_object($thumbnail)) {
    ?>
        <div class="ccm-block-page-list-page-entry-thumbnail">
            <?php
            $img = Core::make('html/image', ['f' => $thumbnail]);
            $tag = $img->getTag();
            $tag->addClass('img-fluid');
            echo $tag; ?>
        </div>
    <?php
    } ?>
<?php echo $description ?>

</section>


<?php $view->inc('elements/footer.php'); ?>