<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>


<?php if (!empty($title)): ?>
    <?php echo h($title); ?>
<?php endif; ?>


<?php if (!empty($image_link)): ?>
    <?php // Original image ?>
    <img src="<?php echo $image_link; ?>" alt="<?php echo h($image_alt); ?>" width="<?php echo $image_width; ?>" height="<?php echo $image_height; ?>">
<?php endif; ?>


